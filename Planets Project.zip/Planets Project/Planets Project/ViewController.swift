//
//  ViewController.swift
//  Planets Project
//
//  Created by OmairAljabri on 23/01/1443 AH.
//

import UIKit
import ARKit
class ViewController: UIViewController {

    @IBOutlet weak var sceneView: ARSCNView!
    let configuration = ARWorldTrackingConfiguration()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.sceneView.debugOptions = [ARSCNDebugOptions.showFeaturePoints, ARSCNDebugOptions.showWorldOrigin]
        self.sceneView.session.run(configuration)
        
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        let sun = SCNNode()
        sun.geometry = SCNSphere(radius: 0.2)
        sun.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "2k_sun.jpg")
        sun.position = SCNVector3(0,0,0.5)
        self.sceneView.scene.rootNode.addChildNode(sun)
        
        let earth = SCNNode()
        earth.geometry = SCNSphere(radius: 0.2)
        earth.geometry?.firstMaterial?.diffuse.contents = UIImage(named: "2k_earth_daymap.jpg")
        earth.position = SCNVector3(0,0,-0.5)
        self.sceneView.scene.rootNode.addChildNode(earth)

    }
}

